document.addEventListener('DOMContentLoaded', () => {
    // State management
    let tasks = JSON.parse(localStorage.getItem('deadline_tasks')) || [];
    let completedCount = parseInt(localStorage.getItem('deadline_completed_count')) || 0;
    let selectedDateFilter = null;

    // DOM Elements
    const deadlineList = document.getElementById('deadline-list');
    const addTaskBtn = document.getElementById('add-task-btn');
    const taskModal = document.getElementById('task-modal');
    const taskForm = document.getElementById('task-form');
    const closeModalBtn = document.getElementById('close-modal');
    const totalTasksCountEl = document.getElementById('total-tasks-count');
    const completionPercentageEl = document.getElementById('completion-percentage');
    const urgencyScoreEl = document.getElementById('urgency-score');
    const productivityRing = document.getElementById('productivity-ring');
    const progressPercentEl = document.getElementById('progress-percent');
    const calendarDaysEl = document.getElementById('calendar-days');

    // Constants for productivity ring
    const radius = 52;
    const circumference = 2 * Math.PI * radius;
    if(productivityRing) {
        productivityRing.style.strokeDasharray = `${circumference} ${circumference}`;
    }

    // --- Core Functions ---

    function saveToLocalStorage() {
        localStorage.setItem('deadline_tasks', JSON.stringify(tasks));
        localStorage.setItem('deadline_completed_count', completedCount);
    }

    function calculateUrgency(deadline) {
        const now = new Date().getTime();
        const diff = new Date(deadline).getTime() - now;
        const hours = diff / (1000 * 60 * 60);

        if (hours < 0) return 'expired';
        if (hours < 6) return 'critical';
        if (hours < 24) return 'warning';
        return 'safe';
    }

    function getUrgencyColorClass(urgency) {
        switch (urgency) {
            case 'critical': return 'critical';
            case 'warning': return 'warning';
            case 'safe': return 'safe';
            default: return 'critical';
        }
    }

    function calculateAnxietyScore() {
        if (tasks.length === 0) return 0.0;
        
        let totalScore = 0;
        tasks.forEach(task => {
            const diff = new Date(task.deadline).getTime() - new Date().getTime();
            const hours = diff / (1000 * 60 * 60);
            
            if (hours <= 0) totalScore += 10;
            else if (hours < 24) totalScore += 8;
            else if (hours < 72) totalScore += 5;
            else totalScore += 2;
        });

        const rawScore = totalScore / (tasks.length || 1);
        return Math.min(rawScore, 10).toFixed(1);
    }
    
    function updateAnxietyUI() {
        const score = parseFloat(calculateAnxietyScore());
        const percent = tasks.length === 0 ? 0 : Math.round((score / 10) * 100);
        
        const card = document.querySelector('.anxiety-card');
        const badge = document.getElementById('anxiety-badge');
        const emoji = document.getElementById('anxiety-emoji');
        const valueP = document.getElementById('anxiety-value-percent');
        const msg = document.getElementById('anxiety-message');
        
        if(card && badge && emoji && valueP && msg) {
            valueP.textContent = `${percent}%`;
            
            card.classList.remove('state-calm', 'state-warning', 'state-critical');
            
            if (tasks.length === 0) {
                card.classList.add('state-calm');
                badge.textContent = 'Rest Mode';
                emoji.textContent = '😴';
                msg.textContent = "No active deadlines. Enjoy your free time!";
            } else if (score <= 3.5) {
                card.classList.add('state-calm');
                badge.textContent = 'Calm Mode';
                emoji.textContent = '😊';
                msg.textContent = "You're safe. Keep up the good pace.";
            } else if (score <= 7.0) {
                card.classList.add('state-warning');
                badge.textContent = 'Pressure Rising';
                emoji.textContent = '😐';
                msg.textContent = "Stay focused. Deadlines are approaching.";
            } else {
                card.classList.add('state-critical');
                badge.textContent = 'Critical Zone';
                emoji.textContent = '😰';
                msg.textContent = "Act NOW! Deadlines are critical.";
            }
        }
    }

    function updateStats() {
        const total = tasks.length + completedCount;
        const percentage = total === 0 ? 0 : Math.round((completedCount / total) * 100);
        
        if(totalTasksCountEl) totalTasksCountEl.textContent = tasks.length;
        if(completionPercentageEl) completionPercentageEl.textContent = `${percentage}%`;
        if(urgencyScoreEl) urgencyScoreEl.textContent = calculateAnxietyScore();
        
        // Update Ring
        if(productivityRing && progressPercentEl) {
            const offset = circumference - (percentage / 100) * circumference;
            productivityRing.style.strokeDashoffset = offset;
            progressPercentEl.textContent = `${percentage}%`;
        }

        const activeTasksCountEl = document.getElementById('active-tasks-count');
        const completedTasksCountEl = document.getElementById('completed-tasks-count');
        if (activeTasksCountEl) activeTasksCountEl.textContent = tasks.length;
        if (completedTasksCountEl) completedTasksCountEl.textContent = completedCount;
        
        updateAnxietyUI();
    }

    function formatTime(ms) {
        if (ms < 0) return { d: 0, h: 0, m: 0, s: 0 };
        const d = Math.floor(ms / (1000 * 60 * 60 * 24));
        const h = Math.floor((ms % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((ms % (1000 * 60)) / 1000);
        return { d, h, m, s };
    }

    function renderTasks() {
        deadlineList.innerHTML = '';
        
        tasks.sort((a, b) => new Date(a.deadline) - new Date(b.deadline));
        
        let displayTasks = tasks;
        if (selectedDateFilter) {
            displayTasks = tasks.filter(t => t.deadline.startsWith(selectedDateFilter));
        }

        displayTasks.forEach(task => {
            const urgency = calculateUrgency(task.deadline);
            const colorClass = getUrgencyColorClass(urgency);
            const diff = new Date(task.deadline).getTime() - new Date().getTime();
            const time = formatTime(diff);

            const taskEl = document.createElement('div');
            taskEl.className = `deadline-item ${colorClass}`;
            taskEl.innerHTML = `
                <div class="urgency-line ${colorClass}"></div>
                <div class="task-main">
                    <div class="task-info">
                        <h4>${task.title}</h4>
                        <p>${task.subject}</p>
                    </div>
                    <div class="task-actions">
                        <button class="btn-icon complete" data-id="${task.id}" title="Complete">
                            <i class="fas fa-check"></i>
                        </button>
                        <button class="btn-icon delete" data-id="${task.id}" title="Delete">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
                <div class="countdown" id="timer-${task.id}">
                    <div class="time-unit">
                        <span class="time-val">${String(time.d).padStart(2, '0')}</span>
                        <span class="time-label">Days</span>
                    </div>
                    <div class="time-unit">
                        <span class="time-val">${String(time.h).padStart(2, '0')}</span>
                        <span class="time-label">Hrs</span>
                    </div>
                    <div class="time-unit">
                        <span class="time-val">${String(time.m).padStart(2, '0')}</span>
                        <span class="time-label">Min</span>
                    </div>
                    <div class="time-unit">
                        <span class="time-val">${String(time.s).padStart(2, '0')}</span>
                        <span class="time-label">Sec</span>
                    </div>
                </div>
            `;
            deadlineList.appendChild(taskEl);
        });

        // Add event listeners to buttons
        document.querySelectorAll('.btn-icon.complete').forEach(btn => {
            btn.onclick = () => completeTask(btn.dataset.id);
        });
        document.querySelectorAll('.btn-icon.delete').forEach(btn => {
            btn.onclick = () => deleteTask(btn.dataset.id);
        });
    }

    function updateTimers() {
        tasks.forEach(task => {
            const timerEl = document.getElementById(`timer-${task.id}`);
            if (timerEl) {
                const diff = new Date(task.deadline).getTime() - new Date().getTime();
                const time = formatTime(diff);
                const vals = timerEl.querySelectorAll('.time-val');
                vals[0].textContent = String(time.d).padStart(2, '0');
                vals[1].textContent = String(time.h).padStart(2, '0');
                vals[2].textContent = String(time.m).padStart(2, '0');
                vals[3].textContent = String(time.s).padStart(2, '0');

                // Update urgency color dynamically
                const urgency = calculateUrgency(task.deadline);
                const colorClass = getUrgencyColorClass(urgency);
                const itemEl = timerEl.closest('.deadline-item');
                const line = itemEl.querySelector('.urgency-line');
                
                itemEl.className = `deadline-item ${colorClass}`;
                line.className = `urgency-line ${colorClass}`;
            }
        });
        
        updateStats();
    }

    function completeTask(id) {
        tasks = tasks.filter(t => t.id !== id);
        completedCount++;
        saveToLocalStorage();
        renderTasks();
        updateStats();
        generateCalendar();
    }

    function deleteTask(id) {
        tasks = tasks.filter(t => t.id !== id);
        saveToLocalStorage();
        renderTasks();
        updateStats();
        generateCalendar();
    }

    function generateCalendar() {
        if(!calendarDaysEl) return;
        const now = new Date();
        const year = now.getFullYear();
        const month = now.getMonth();
        const today = now.getDate();

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        calendarDaysEl.innerHTML = '';
        
        // Days labels
        ['S', 'M', 'T', 'W', 'T', 'F', 'S'].forEach(d => {
            const el = document.createElement('div');
            el.className = 'day';
            el.style.fontWeight = 'bold';
            el.textContent = d;
            calendarDaysEl.appendChild(el);
        });

        // Fill empty slots
        for (let i = 0; i < (firstDay === 0 ? 0 : firstDay); i++) {
            const el = document.createElement('div');
            el.className = 'day';
            calendarDaysEl.appendChild(el);
        }

        // Fill days
        for (let i = 1; i <= daysInMonth; i++) {
            const el = document.createElement('div');
            el.className = 'day';
            
            const targetDateStr = `${year}-${String(month+1).padStart(2,'0')}-${String(i).padStart(2,'0')}`;
            
            if (i === today) el.classList.add('active');
            if (selectedDateFilter === targetDateStr) el.classList.add('selected');
            
            // Check if any deadline falls on this day
            const hasDeadline = tasks.some(t => {
                const d = new Date(t.deadline);
                return d.getDate() === i && d.getMonth() === month && d.getFullYear() === year;
            });
            if (hasDeadline) {
                el.classList.add('has-deadline');
            }
            
            el.textContent = i;
            
            // Filter click handler
            el.onclick = () => {
                if(el.classList.contains('selected')) {
                    el.classList.remove('selected');
                    selectedDateFilter = null;
                } else {
                    calendarDaysEl.querySelectorAll('.day').forEach(d => d.classList.remove('selected'));
                    el.classList.add('selected');
                    selectedDateFilter = targetDateStr;
                }
                renderTasks();
                // update tab styling
                const allTab = document.querySelector('.filter-tabs .tab:first-child');
                if(allTab) {
                    document.querySelectorAll('.filter-tabs .tab').forEach(t=>t.classList.remove('active'));
                    allTab.classList.add('active');
                }
            };
            
            calendarDaysEl.appendChild(el);
        }
    }

    // --- Custom Date/Time Picker Logic ---
    const pickerTrigger = document.getElementById('custom-picker-trigger');
    const pickerDropdown = document.getElementById('custom-picker-dropdown');
    const pickerCalendarGrid = document.getElementById('picker-calendar-grid');
    const hiddenDeadlineInput = document.getElementById('task-deadline');
    const pickerPreviewText = document.getElementById('picker-preview-text');
    const pickerSetBtn = document.getElementById('picker-set');
    const pickerClearBtn = document.getElementById('picker-clear');
    const triggerText = document.getElementById('trigger-text');
    const wheelHours = document.getElementById('wheel-hours');
    const wheelMinutes = document.getElementById('wheel-minutes');
    const ampmBtns = document.querySelectorAll('.ampm-btn');
    
    let pickerDate = new Date();
    let selectedPickerDate = null;
    let selectedHour = "11";
    let selectedMinute = "59";
    let selectedAmPm = "PM";

    if(wheelHours) {
        for(let i = 1; i <= 12; i++) {
            let span = document.createElement('div');
            span.className = 'wheel-item' + (i === 11 ? ' active' : '');
            span.textContent = String(i).padStart(2, '0');
            span.onclick = () => {
                wheelHours.querySelectorAll('.wheel-item').forEach(el=>el.classList.remove('active'));
                span.classList.add('active');
                selectedHour = span.textContent;
                span.scrollIntoView({ behavior: 'smooth', block: 'center' });
                updatePickerPreview();
            };
            wheelHours.appendChild(span);
        }
        for(let i = 0; i < 60; i+=1) {
            let span = document.createElement('div');
            span.className = 'wheel-item' + (i === 59 ? ' active' : '');
            span.textContent = String(i).padStart(2, '0');
            span.onclick = () => {
                wheelMinutes.querySelectorAll('.wheel-item').forEach(el=>el.classList.remove('active'));
                span.classList.add('active');
                selectedMinute = span.textContent;
                span.scrollIntoView({ behavior: 'smooth', block: 'center' });
                updatePickerPreview();
            };
            wheelMinutes.appendChild(span);
        }
        
        ampmBtns.forEach(btn => {
            btn.onclick = () => {
                ampmBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                selectedAmPm = btn.dataset.val;
                updatePickerPreview();
            };
        });
    }

    function updatePickerPreview() {
        if (!selectedPickerDate) {
            pickerPreviewText.textContent = "Pick a date";
            document.getElementById('picker-soon-badge').style.display = 'none';
            return;
        }
        const opts = { month: 'short', day: 'numeric', year: 'numeric' };
        const dStr = selectedPickerDate.toLocaleDateString('en-US', opts);
        pickerPreviewText.textContent = `${dStr}, ${selectedHour}:${selectedMinute} ${selectedAmPm}`;
        
        let h = parseInt(selectedHour);
        if (selectedAmPm === "PM" && h < 12) h += 12;
        if (selectedAmPm === "AM" && h === 12) h = 0;
        
        const finalTime = new Date(selectedPickerDate);
        finalTime.setHours(h, parseInt(selectedMinute), 0, 0);
        
        const diffDays = Math.ceil((finalTime.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
        const badge = document.getElementById('picker-soon-badge');
        badge.style.display = 'inline-block';
        if (diffDays < 0) {
            badge.textContent = "Past";
            badge.style.background = 'var(--text-secondary)';
            badge.style.color = '#fff';
        } else if (diffDays === 0) {
            badge.textContent = "Today";
            badge.style.background = 'var(--neon-red)';
            badge.style.color = '#fff';
        } else if (diffDays < 3) {
            badge.textContent = "Soon";
            badge.style.background = 'var(--neon-yellow)';
            badge.style.color = 'var(--bg-dark)';
        } else {
            badge.textContent = "in " + diffDays + " days";
            badge.style.background = 'var(--neon-green)';
            badge.style.color = 'var(--bg-dark)';
        }
    }

    function renderPickerCalendar() {
        if(!pickerCalendarGrid) return;
        const year = pickerDate.getFullYear();
        const month = pickerDate.getMonth();
        document.getElementById('picker-month-year').textContent = pickerDate.toLocaleDateString('en-US', {month:'short', year:'numeric'});
        
        pickerCalendarGrid.innerHTML = '';
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        for (let i = 0; i < firstDay; i++) {
            const el = document.createElement('div'); el.className = 'day'; pickerCalendarGrid.appendChild(el);
        }
        for (let i = 1; i <= daysInMonth; i++) {
            const el = document.createElement('div');
            el.className = 'day';
            el.textContent = i;
            
            if (selectedPickerDate && selectedPickerDate.getDate() === i && selectedPickerDate.getMonth() === month && selectedPickerDate.getFullYear() === year) {
                el.classList.add('selected');
            }
            
            el.onclick = () => {
                pickerCalendarGrid.querySelectorAll('.day').forEach(d => d.classList.remove('selected'));
                el.classList.add('selected');
                selectedPickerDate = new Date(year, month, i);
                updatePickerPreview();
            };
            pickerCalendarGrid.appendChild(el);
        }
    }

    if(document.getElementById('picker-prev-month')) {
        document.getElementById('picker-prev-month').onclick = () => { pickerDate.setMonth(pickerDate.getMonth() - 1); renderPickerCalendar(); };
        document.getElementById('picker-next-month').onclick = () => { pickerDate.setMonth(pickerDate.getMonth() + 1); renderPickerCalendar(); };
    }

    if(pickerTrigger) {
        pickerTrigger.onclick = () => {
            pickerDropdown.classList.toggle('active');
            if(pickerDropdown.classList.contains('active')){
                renderPickerCalendar();
            }
        };
        
        pickerClearBtn.onclick = () => {
            selectedPickerDate = null;
            hiddenDeadlineInput.value = '';
            triggerText.textContent = "Select Date & Time";
            pickerDropdown.classList.remove('active');
            renderPickerCalendar();
            updatePickerPreview();
        };

        pickerSetBtn.onclick = () => {
            if (!selectedPickerDate) {
                alert("Please select a date first");
                return;
            }
            let h = parseInt(selectedHour);
            if (selectedAmPm === "PM" && h < 12) h += 12;
            if (selectedAmPm === "AM" && h === 12) h = 0;
            
            const iso = `${selectedPickerDate.getFullYear()}-${String(selectedPickerDate.getMonth()+1).padStart(2,'0')}-${String(selectedPickerDate.getDate()).padStart(2,'0')}T${String(h).padStart(2,'0')}:${selectedMinute}`;
            hiddenDeadlineInput.value = iso;
            
            triggerText.textContent = pickerPreviewText.textContent;
            pickerDropdown.classList.remove('active');
        };

        window.addEventListener('click', (e) => {
            if (!e.target.closest('.custom-picker-group') && pickerDropdown.classList.contains('active')) {
                pickerDropdown.classList.remove('active');
            }
        });
    }

    // --- Event Listeners ---

    if(addTaskBtn) addTaskBtn.onclick = () => taskModal.classList.add('active');
    if(closeModalBtn) closeModalBtn.onclick = () => taskModal.classList.remove('active');
    
    // Close modal on click outside
    window.addEventListener('click', (e) => {
        if (taskModal && e.target === taskModal) taskModal.classList.remove('active');
    });

    if(taskForm) {
        taskForm.onsubmit = (e) => {
            e.preventDefault();
            
            if (!hiddenDeadlineInput.value) {
                alert("Please set a valid deadline via the custom date/time picker");
                pickerDropdown.classList.add('active');
                renderPickerCalendar();
                return;
            }

            const newTask = {
                id: Date.now().toString(),
                title: document.getElementById('task-title').value,
                subject: document.getElementById('task-subject').value,
                deadline: hiddenDeadlineInput.value,
                created: new Date().toISOString()
            };

            tasks.push(newTask);
            saveToLocalStorage();
            renderTasks();
            updateStats();
            generateCalendar();
            taskForm.reset();
            
            // clear picker state manually for next open
            selectedPickerDate = null;
            hiddenDeadlineInput.value = '';
            triggerText.textContent = "Select Date & Time";
            updatePickerPreview();
            
            taskModal.classList.remove('active');
        };
    }

    // --- Initialization ---
    renderTasks();
    updateStats();
    generateCalendar();
    
    // Run timer updates every second
    setInterval(updateTimers, 1000);
});
